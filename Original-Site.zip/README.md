## Welcome!

Hey, if you're here that's actually a tad surprising, but this is the repo running my personal website [alecgrover.com](https://alecgrover.com). I encourage you to go check it out!


Thanks to Jerome Lachaud, my site is based out of their Freelancer layout for Jekyll, and while I have added a solid bit of personal tweaking to it, I couldn't have got things running this fast without their work!

Freelancer Jekyll theme  [![Build Status](https://api.travis-ci.org/jeromelachaud/freelancer-theme.svg?branch=master)](https://travis-ci.org/jeromelachaud/freelancer-theme/) 
=========================
