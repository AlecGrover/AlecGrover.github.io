source "https://rubygems.org"

gem "jekyll"

group :jekyll_plugins do
    gem "jekyll-feed"
    gem "jekyll-seo-tag"
end
